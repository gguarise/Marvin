﻿namespace Atm.Atendimento.Domain.Enum
{
    public enum StatusEnum
    {
        None,
        Cadastrado,
        Agendado,
        Finalizado
    }
}
