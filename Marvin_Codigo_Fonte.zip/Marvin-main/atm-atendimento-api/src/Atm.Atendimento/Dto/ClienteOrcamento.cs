﻿using Atm.Atendimento.Domain;
using System;

namespace Atm.Atendimento.Dto
{
    public class ClienteOrcamento : Entity
    {
        public Guid IdExterno { get; set; }
    }
}
