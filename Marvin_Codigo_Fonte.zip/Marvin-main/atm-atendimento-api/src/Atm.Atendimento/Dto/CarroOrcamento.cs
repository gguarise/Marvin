﻿using Atm.Atendimento.Domain;
using System;

namespace Atm.Atendimento.Dto
{
    public class CarroOrcamento : Entity
    {
        public Guid IdExterno { get; set; }
    }
}
