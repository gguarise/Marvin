﻿using System;

namespace Atm.Atendimento.Api.Features.Orçamentos.Commands.InserirOrcamentoFeature
{
    public class InserirOrcamentoCommandResponse
    {
        public Guid Id { get; set; }
        public DateTime Datacadastro { get; set; }
    }
}
