﻿using System;

namespace Atm.Atendimento.Api.Features.Orçamentos.Commands.AtualizarOrcamentoFeature
{
    public class AtualizarOrcamentoCommandResponse
    {
        public DateTime? DataAtualizacao { get; set; }
    }
}
