export class TabelaFipe {
  code: string;
  name: string;
}
