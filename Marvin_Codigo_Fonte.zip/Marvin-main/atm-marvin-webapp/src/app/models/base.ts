export class BaseModel {
  id: string;
  select: boolean;
  modified: boolean;
  new: boolean;
}
