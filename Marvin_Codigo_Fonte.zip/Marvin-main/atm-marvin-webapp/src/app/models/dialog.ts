export class Dialog {
  title: string;
  content: string;
}
