import { BaseModel } from './base';

export class Servico extends BaseModel {
  nome: string;
}
