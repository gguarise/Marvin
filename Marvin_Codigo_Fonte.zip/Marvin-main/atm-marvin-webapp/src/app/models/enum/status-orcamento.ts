export enum StatusOrcamento {
  Cadastrado = 'Cadastrado',
  Agendado = 'Agendado',
  Finalizado = 'Finalizado',
}
